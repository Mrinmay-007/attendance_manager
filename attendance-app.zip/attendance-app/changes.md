# Changes made — unused-code cleanup

I traced the real import graph starting from `src/main.jsx` → `src/App.jsx`. The
live app only reaches:

```
main.jsx
└─ App.jsx
   ├─ pages/Login.jsx        → components/logo.jsx
   ├─ pages/manual.jsx
   ├─ auth/ProtectedRoute.jsx
   └─ pages/Admin.jsx, pages/Faculty.jsx, pages/Student.jsx
      └─ components/RolePortal.jsx   (self-contained, only imports lucide-react + components/api.jsx)
```

Everything else under `src/dashboard/`, `src/components/Admin/`,
`src/components/Teacher/`, `src/components/Student/`, plus
`src/components/logout.jsx` and `src/auth/authProvider.jsx`, is **never
imported from that tree**. It looks like an earlier version of the app (one
page/component per feature) that was later replaced by the single
`RolePortal.jsx` component, but the old files were never deleted or removed
from routing — they're dead code sitting in the bundle.

I did **not** delete any files — I commented out their contents and left a
note at the top of each explaining why, per your instructions. Nothing here
was fixed, only commented.

## Files fully commented out (entirely unreachable/unused)

Each of these got a header comment added, then every line of the original
code was turned into a `//` comment:

- `src/auth/authProvider.jsx` — a `react-admin`-style auth provider object, never imported anywhere.
- `src/components/logout.jsx` — a `Logout` button component. It was only ever imported by the other dead files below (never by `RolePortal.jsx`, which has its own inline `logout()` function).
- `src/components/Student/getNotice.jsx` (`NoticeBoard`)
- `src/components/Student/getRoutine.jsx` (`Routine`)
- `src/components/Student/settings.jsx` (`Settings`)
- `src/components/Student/showAttendance.jsx`
- `src/components/Admin/adminSetting.jsx`
- `src/components/Admin/nav.jsx` (`Nav`)
- `src/components/Admin/routine.jsx`
- `src/components/Teacher/attendance.jsx`
- `src/components/Teacher/attendanceForm.jsx`
- `src/components/Teacher/editAttendance.jsx`
- `src/components/Teacher/teacherDetails.jsx` (`Details`)
- `src/components/Teacher/teacherInfo.jsx` (`Info`)
- `src/components/Teacher/teacherRoutine.jsx`
- `src/dashboard/adminDashboard.jsx`
- `src/dashboard/teacherDashboard.jsx`
- `src/dashboard/studentDashboard.jsx`

## Files already commented out by whoever wrote them (left as-is, just flagging)

These had no active code at all already — only old commented-out drafts. I
didn't touch them, just noting them here since they're unused too:

- `src/components/resetPw.jsx`
- `src/components/notice.jsx`
- `src/pages/feedback.jsx` — also not routed in `App.jsx` (its import/route in `App.jsx` was already commented out by whoever wrote it).

## Small in-place edit (live file, not fully dead)

- `src/pages/Login.jsx` — commented out `import React from "react"`. It's on React 19 with Vite's automatic JSX runtime, and `React` was never referenced directly in the file, so the import was unused. Kept `{ useState }` import active since that's actually used.
- `src/components/RolePortal.jsx` — inside `DataTable`'s `displayValue()` function, two `if` branches (`subject-teachers` + `subject_name`, and `subject-teachers` + `teacher_name`) were exact duplicates of two branches a few lines above, so they could never run (the earlier branch always returns first). Commented those two duplicate branches out — see the bug note below.

No other unused imports/variables were found in the files that are actually
reachable from the router (`App.jsx`, `RolePortal.jsx`, `Login.jsx`,
`ProtectedRoute.jsx`, `Logo.jsx`, `api.jsx`, `main.jsx`, `manual.jsx`,
`Admin.jsx`, `Faculty.jsx`, `Student.jsx`).

I re-ran `npm run build` after making these changes and it completed
successfully, so nothing that's actually used got broken.

---

# Bugs found (NOT fixed — for you to handle)

1. **Two parallel implementations, one totally dead.** As described above,
   an entire earlier generation of per-role dashboards and feature pages
   (routine, attendance, notices, settings, etc.) still exists in the repo
   but is completely unreachable — `App.jsx` never routes to any of it. If
   any of those screens have functionality that `RolePortal.jsx` doesn't
   (e.g. a formatted routine table with day/slot columns, the rich-text
   notice board, bulk attendance editing UI in `editAttendance.jsx`), that
   functionality currently doesn't exist anywhere in the live app.

2. **`src/pages/manual.jsx` has invalid HTML nesting.** A `<ul>`, several
   `<li>`s, and a `<strong>` are placed directly inside a `<p>`. Block-level
   elements aren't valid children of `<p>` — browsers will silently close
   the `<p>` early, so the manual page won't render with the structure the
   JSX implies.

3. **Duplicate/dead branches in `RolePortal.jsx`'s `displayValue()`.**
   (Now commented out — see above.) Two `if` conditions were byte-for-byte
   duplicates of two earlier conditions in the same function, so they were
   unreachable even before this cleanup. Not a functional bug (the earlier
   branches produce the same result), just leftover copy-paste.

4. **Leftover debug `console.log`** in the now-dead `src/components/logout.jsx`
   (`console.log("User logged out.")`). Harmless since the file is unused,
   but worth removing if that component is ever revived.

5. **Missing `email` dependency** in the now-dead
   `src/components/Student/getNotice.jsx`: its `useEffect(() => {...}, [])`
   reads `email` from `localStorage` but doesn't list it in the dependency
   array. If that component is ever wired back into the app, a changed
   `email` wouldn't re-trigger the fetch.

6. **`.env` is not in `.gitignore`.** `.gitignore` has entries for logs,
   `node_modules`, `dist`, editor folders, etc., but no `.env` or `*.env`
   entry, so the local `.env` file (containing `VITE_API_URL`) could get
   committed by accident.

7. **`vite.config.js` imports `tailwindcss` from `@tailwindcss/vite` but
   never registers it** — `plugins: [react(), // tailwindcss()]`. Tailwind
   still works because `postcss.config.js`/`tailwind.config.js` handle it
   through PostCSS instead, but the unused Vite-plugin import is confusing
   and worth double-checking that's actually the intended setup.

8. **`package.json` has a number of dependencies that are no longer used
   anywhere in the live app** now that the dead files above are commented
   out (they were only used there before, too) — `@mui/material`,
   `@mui/icons-material`, `@emotion/react`, `@emotion/styled`, `ag-grid-community`,
   `ag-grid-react`, `axios`, `dayjs`, `react-hook-form`, `@hookform/resolvers`,
   `zod`, `@radix-ui/react-dropdown-menu`, `framer-motion`,
   `@fontsource/roboto`, `tailwindcss-animate`. Not touched (that's a
   `package.json`/dependency decision, not source code), just flagging the
   bloat for whenever you prune it.
